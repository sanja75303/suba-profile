import { FiArrowDownRight, FiArrowUpRight } from 'react-icons/fi'
import profileImage from '../assets/profile.jpeg'

function Hero() {
  return (
    <section className="hero-section" id="home" aria-labelledby="hero-title">
      <div className="hero-layout page-width">
        <div className="hero-copy">
          <p className="eyebrow"><span className="eyebrow-line" /> Legal research & scholarship</p>
          <h1 id="hero-title">A. <em>Subashree</em></h1>
          <p className="hero-role">BA.LLB (Hons) Student <span aria-hidden="true">|</span> Legal Researcher</p>
          <p className="hero-institution">Saveetha School of Law</p>
          <p className="hero-intro">Exploring the intersections of law, public policy and social justice through careful, people-centred research.</p>
          <div className="hero-actions">
            <a className="button button-primary" href="#research">View my research <FiArrowDownRight aria-hidden="true" /></a>
            <a className="button button-text" href="#contact">Contact me <FiArrowUpRight aria-hidden="true" /></a>
          </div>
          <span className="hero-index">01 <span /> 10</span>
        </div>
        <div className="portrait-column">
          <div className="portrait-frame">
            {profileImage ? <img className="profile-image" src={profileImage} alt="A. Subashree" /> : (
              <div className="portrait-placeholder" aria-label="Profile photograph not yet added"><span>AS</span><small>Profile photograph</small></div>
            )}
          </div>
          <p className="portrait-caption"><span>01 /</span> Student researcher · Tamil Nadu, India</p>
        </div>
      </div>
      <div className="hero-rule" />
    </section>
  )
}

export default Hero