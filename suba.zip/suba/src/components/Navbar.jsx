import { useEffect, useState } from 'react'
import { FiMenu, FiX } from 'react-icons/fi'

function Navbar({ items, activeSection }) {
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('keydown', closeOnEscape)
    return () => window.removeEventListener('keydown', closeOnEscape)
  }, [])

  const closeMenu = () => setMenuOpen(false)

  return (
    <header className="site-header">
      <nav className="navbar page-width" aria-label="Main navigation">
        <a className="wordmark" href="#home" onClick={closeMenu} aria-label="A. Subashree, home">
          <span className="wordmark-mark">AS</span>
          <span className="wordmark-name">A. Subashree</span>
        </a>
        <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={menuOpen} aria-controls="primary-navigation" onClick={() => setMenuOpen((open) => !open)}>
          {menuOpen ? <FiX aria-hidden="true" /> : <FiMenu aria-hidden="true" />}
        </button>
        <div className={`nav-links${menuOpen ? ' nav-links-open' : ''}`} id="primary-navigation">
          {items.map(({ id, label }) => (
            <a key={id} href={`#${id}`} className={activeSection === id ? 'nav-link nav-link-active' : 'nav-link'} aria-current={activeSection === id ? 'location' : undefined} onClick={closeMenu}>{label}</a>
          ))}
        </div>
      </nav>
    </header>
  )
}

export default Navbar