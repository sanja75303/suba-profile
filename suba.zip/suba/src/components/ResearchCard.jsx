function ResearchCard({ item, index }) {
  const categoryClass = item.category.toLowerCase().replace(/[^a-z]+/g, '-')

  return (
    <article className={`research-card research-card-${categoryClass}`}>
      <div className="research-card-top"><span className="research-number">{String(index + 1).padStart(2, '0')}</span><span className="research-category">{item.category}</span></div>
      <h3>{item.title}</h3>
      <p className="research-focus">{item.focus}</p>
      {item.publishedUrl && (
        <a className="research-published-link" href={item.publishedUrl} target="_blank" rel="noopener noreferrer">
          View Published Paper <span aria-hidden="true">→</span>
        </a>
      )}
    </article>
  )
}

export default ResearchCard