import { FiArrowUpRight } from 'react-icons/fi'

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner page-width">
        <a className="footer-name" href="#home">A. Subashree</a>
        <p>Legal research, grounded in curiosity and a commitment to justice.</p>
        <a className="back-to-top" href="#home">Back to top <FiArrowUpRight aria-hidden="true" /></a>
        <span className="footer-copyright">© 2026 A. Subashree</span>
      </div>
    </footer>
  )
}

export default Footer