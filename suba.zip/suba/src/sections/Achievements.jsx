import { FiAward, FiBriefcase, FiTarget } from 'react-icons/fi'

const achievements = [
  { title: 'Young Drawing Achiever Award', Icon: FiAward },
  { title: 'State Silver Medalist in Karate Championships', Icon: FiTarget },
  { title: 'Hands-on Experience About Legal Procedure in Singapore', Icon: FiBriefcase },
]

function Achievements() {
  return (
    <section className="section section-achievements" id="achievements" aria-labelledby="achievements-title">
      <div className="page-width">
        <div className="section-heading" data-reveal>
          <p className="eyebrow">Achievements</p>
          <h2 id="achievements-title">Achievements</h2>
        </div>
        <div className="achievement-grid">
          {achievements.map(({ title, Icon }) => (
            <article className="achievement-card" key={title}>
              <span className="achievement-icon"><Icon aria-hidden="true" /></span>
              <h3>{title}</h3>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Achievements