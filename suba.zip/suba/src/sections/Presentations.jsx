import { presentations } from '../data/presentations.js'

function Presentations() {
  return (
    <section className="section section-presentations" id="presentations" aria-labelledby="presentations-title">
      <div className="page-width presentations-layout">
        <div className="section-heading" data-reveal><p className="eyebrow">Conference work</p><h2 id="presentations-title">Papers <em>presented</em></h2></div>
        <div className="presentation-list">{presentations.map((item, index) => <article className="presentation-item" key={item.title} data-reveal><span className="presentation-index">0{index + 1}</span><div><h3>{item.title}</h3><p>{item.conference}</p></div><span className="presentation-badge">Award recipient</span></article>)}</div>
      </div>
    </section>
  )
}

export default Presentations