import { coordinatedEvents } from '../data/events.js'

function Events() {
  return (
    <section className="section section-events" id="events" aria-labelledby="events-title">
      <div className="page-width">
        <div className="section-heading" data-reveal><p className="eyebrow">Academic community</p><h2 id="events-title">Academic events <em>coordinated</em></h2></div>
        <div className="event-grid">
          {coordinatedEvents.map((event, index) => (
            <article className="event-card" key={event.title}>
              <div className="event-date-panel"><span className="event-number">{String(index + 1).padStart(2, '0')}</span><time>{event.date}</time></div>
              <div className="event-title-panel"><h3>{event.title}</h3></div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Events