import { FiArrowUpRight, FiGlobe, FiMail } from 'react-icons/fi'

function Contact() {
  return (
    <section className="section section-contact" id="contact" aria-labelledby="contact-title">
      <div className="page-width contact-layout">
        <div className="contact-copy" data-reveal><p className="eyebrow">Start a conversation</p><h2 id="contact-title">Let’s discuss ideas <em>that matter.</em></h2><a className="contact-email" href="mailto:subassllaw@gmail.com">subassllaw@gmail.com <FiArrowUpRight aria-hidden="true" /></a></div>
        <div className="contact-details" data-reveal>
          <div><FiMail aria-hidden="true" /><span><small>Email</small><a href="mailto:subassllaw@gmail.com">subassllaw@gmail.com</a></span></div>
          <div><FiGlobe aria-hidden="true" /><span><small>Location</small><strong>Kanchipuram, Tamil Nadu</strong></span></div>
          <div className="language-detail"><span className="language-mark" aria-hidden="true">Aa</span><span><small>Languages</small><strong>Tamil, English</strong></span></div>
        </div>
      </div>
    </section>
  )
}

export default Contact