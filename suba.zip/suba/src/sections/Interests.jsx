const interests = [
  'Constitutional and public policy', 'Gender justice and inclusive jurisprudence', 'Digital safety and cyber law',
  'Technology and legal systems', 'Healthcare equity', 'Political behaviour and digital humanities',
]

function Interests() {
  return (
    <section className="section section-interests" aria-labelledby="interests-title">
      <div className="page-width interests-layout">
        <div className="section-heading" data-reveal><p className="eyebrow">Questions that guide my work</p><h2 id="interests-title">Areas of academic <em>interest</em></h2></div>
        <ul className="interest-list" data-reveal>{interests.map((interest, index) => <li key={interest}><span>0{index + 1}</span>{interest}</li>)}</ul>
      </div>
    </section>
  )
}

export default Interests