const education = [
  { qualification: 'BA.LLB (Hons)', institution: 'Saveetha School of Law', date: 'Expected 2029', result: 'Undergraduate law' },
  { qualification: 'HSC · Maths–Computer Science', institution: 'State Board of Secondary Education, Tamil Nadu', date: 'March 2024', result: '79%' },
  { qualification: 'SSLC', institution: 'State Board of Secondary Education, Tamil Nadu', date: 'May 2022', result: '80%' },
]

function Education() {
  return (
    <section className="section section-education" id="education" aria-labelledby="education-title">
      <div className="page-width education-layout">
        <div className="section-heading" data-reveal><p className="eyebrow">Academic foundation</p><h2 id="education-title">Education</h2></div>
        <div className="education-list">{education.map((item, index) => <article className="education-row" key={item.qualification} data-reveal><span className="education-index">0{index + 1}</span><div className="education-main"><h3>{item.qualification}</h3><p>{item.institution}</p></div><span className="education-date">{item.date}</span><span className="education-result">{item.result}</span></article>)}</div>
      </div>
    </section>
  )
}

export default Education