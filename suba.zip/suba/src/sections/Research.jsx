import { useMemo, useState } from 'react'
import ResearchCard from '../components/ResearchCard.jsx'
import { researchCategories, researchItems } from '../data/research.js'

function Research() {
  const [activeCategory, setActiveCategory] = useState('All')
  const visibleItems = useMemo(() => activeCategory === 'All' ? researchItems : researchItems.filter((item) => item.category === activeCategory), [activeCategory])

  return (
    <section className="section section-research" id="research" aria-labelledby="research-title">
      <div className="page-width">
        <div className="section-heading section-heading-row" data-reveal>
          <div><p className="eyebrow">Selected work</p><h2 id="research-title">Research & <em>publications</em></h2></div>
          <p className="section-intro">A developing body of work across law, technology and the public good.</p>
        </div>
        <div className="filter-row" role="group" aria-label="Filter research by category">
          {researchCategories.map((category) => <button className={`filter-button${activeCategory === category ? ' filter-active' : ''}`} type="button" key={category} aria-pressed={activeCategory === category} onClick={() => setActiveCategory(category)}>{category}</button>)}
        </div>
        <div className="research-grid" aria-live="polite">{visibleItems.map((item) => <ResearchCard item={item} index={researchItems.indexOf(item)} key={item.title} />)}</div>
        <p className="research-note">Publication venues and dates are not listed where they were not supplied.</p>
      </div>
    </section>
  )
}

export default Research