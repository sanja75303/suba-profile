function About() {
  return (
    <section className="section section-about" id="about" aria-labelledby="about-title">
      <div className="page-width about-layout">
        <div className="section-heading" data-reveal><p className="eyebrow">A considered approach</p><h2 id="about-title">About <em>me</em></h2></div>
        <div className="about-copy" data-reveal>
          <p className="about-lede">I am a law student and emerging researcher interested in how legal systems respond to changing social and technological realities.</p>
          <p>At Saveetha School of Law, my academic work spans legal policy, digital safety, gender justice, healthcare equity and the role of technology in public life. I value research that brings doctrinal inquiry and empirical questions into conversation.</p>
          <div className="about-facts"><div><span>01</span><strong>Legal scholarship</strong></div><div><span>02</span><strong>Interdisciplinary inquiry</strong></div><div><span>03</span><strong>Justice-centred research</strong></div></div>
        </div>
      </div>
    </section>
  )
}

export default About