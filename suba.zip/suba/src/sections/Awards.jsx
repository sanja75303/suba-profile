import { FiAward } from 'react-icons/fi'
import { presentations } from '../data/presentations.js'

export function FeaturedAward() {
  const award = presentations[0]
  return (
    <section className="featured-award" aria-labelledby="featured-award-title">
      <div className="page-width featured-award-inner" data-reveal>
        <div className="award-symbol"><FiAward aria-hidden="true" /></div>
        <div className="featured-award-copy"><p className="eyebrow">Featured research award</p><h2 id="featured-award-title">{award.recognition}</h2><p className="featured-paper">“{award.title}”</p><p className="featured-conference">{award.conference}</p></div>
        <span className="award-laurel" aria-hidden="true">RESEARCH<br />& RECOGNITION</span>
      </div>
    </section>
  )
}

function Awards() {
  return (
    <section className="section section-awards" id="awards" aria-labelledby="awards-title">
      <div className="page-width awards-layout">
        <div className="section-heading" data-reveal><p className="eyebrow">Recognition</p><h2 id="awards-title">Awards & <em>credentials</em></h2></div>
        <div className="credential-list" data-reveal>
          <div className="credential-row"><span className="credential-year">Research</span><div><h3>Best Research Paper Presentation Award</h3><p>Beyond the Binary Horizon conference</p></div><FiAward aria-hidden="true" /></div>
          <div className="credential-row"><span className="credential-year">2029</span><div><h3>BA.LLB (Hons) candidate</h3><p>Saveetha School of Law · Expected completion</p></div><span className="credential-mark">SSOL</span></div>
        </div>
      </div>
    </section>
  )
}

export default Awards