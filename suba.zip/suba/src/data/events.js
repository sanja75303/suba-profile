export const coordinatedEvents = [
	{
		title: 'National Conference on the theme "Viksit Bharat @ 2047: Transforming India through Public Policy, Law and Governance"',
		date: '8 October 2025',
	},
	{
		title: 'Special Lecture on Constitution and Democracy in Collaboration with Nallore Vattam, Chennai',
		date: '17 September 2025',
	},
	{
		title: 'One-Day Workshop on Building Resilience and Responsibility: Life Skills for Future-Ready Students',
		date: '4 August 2025',
	},
	{
		title: '4-Day Webinar Series on Constitution and Governance in India at Saveetha School of Law',
		date: '26 August to 30 August 2025',
	},
	{
		title: 'ICSSR-sponsored National Seminar on Social Justice and Equity through Healthcare Delivery System and Governance in India',
		date: '11 & 12 December 2024',
	},
	{
		title: 'International Series Lecture on "FROM THE CODE TO CONSTITUTION: RETHINKING GOVERNANCE IN THE AI ERA"',
		date: '19 January 2026',
	},
	{
		title: 'One Day National Seminar on "Transformative governance: law, ethics and public administration in era of civil service reforms"',
		date: '14 May 2026',
	},
	{
		title: 'An International Conference on "Employment Classification of Gig Workers in India: judicial tests, statutory recognition, and emerging labour standards"',
		date: '27 April 2026',
	},
	{
		title: 'Online Webinar on "International Diplomacy and Lessons from the war in west Asia"',
		date: '9 June 2026',
	},
]