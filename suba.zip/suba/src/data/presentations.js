export const presentations = [
  {
    title: 'DECONSTRUCTING THE GENDER BINARY: A JURISPRUDENTIAL INQUIRY INTO TRANSGENDER RIGHTS AND THE PURSUIT OF INCLUSIVE JUSTICE IN INDIA',
    conference: 'Beyond the Binary Horizon: Advancing Jurisprudential Inclusivity of Transgender Persons in Indian Society',
    recognition: 'Best Research Paper Presentation Award',
  },
]